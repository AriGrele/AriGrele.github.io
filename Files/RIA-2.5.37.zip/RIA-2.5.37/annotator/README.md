#Rapid Image Annotator

This folder contains files associated with version 2.5.37 of the Rapid Image Annotator

## Feature additions:

    - Added keybindings for custom comments
    - Enabled box deselection to add comments to entire image
    - Added cosmetic selections for displaying bounding boxes from corner points, lines from corner points, circles from midpoint and radius
    - Added images remaining and estimated hours remaining to statistics panel
    - Added ability to load custom setting configurations
    - Added error logging to /data/errorlog.txt

## Bug fixes

    - Prevented unspecified image directories from causing a crash on start-up
    - Prevented the annotator from attempting to load images from folders that no longer exist


### License: GNU GPL 3.0. (2023)
