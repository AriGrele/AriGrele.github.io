#Rapid Image Annotator

This folder contains files associated with version 2.2.33 of the Rapid Image Annotator

## Feature additions:

    - Added graphical user interface
    - Added image directory and annotation file loading
    - Added customizable keybindings
    - Added customizable color themes
    - Improved data output format clarity

## Bug fixes

    - Greatly reduced failure rate when loading image data
    - Prevented loading large directories from crashing the application at start-up

### License: GNU GPL 3.0. (2022)
