#Rapid Image Annotator

This folder contains files associated with version 2.5.42 of the Rapid Image Annotator

## Bug fixes

    - Prevented keybindings dialog from saving comments without keybindings
    - Prevented crash from loading settings config files with missing data 

### License: GNU GPL 3.0. (2023)
